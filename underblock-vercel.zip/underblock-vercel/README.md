# Underblock

A neon-grime co-op dungeon crawler. One static page; multiplayer is peer-to-peer
(PeerJS), so there is no server to run.

## Put it on Vercel (no coding)

1. Make a free GitHub account at github.com if you don't have one.
2. On GitHub, click **New repository**, name it `underblock`, keep it Public, click **Create repository**.
3. On the empty repo page, click **uploading an existing file**, drag in `index.html`, `vercel.json` and this `README.md`, then click **Commit changes**.
4. Go to vercel.com, sign up with your GitHub account (the free Hobby plan is fine).
5. Click **Add New → Project**, pick the `underblock` repo, click **Import**.
6. Leave every setting as it is (Framework Preset: Other) and click **Deploy**.
7. In about a minute you get a link like `https://underblock-yourname.vercel.app`. Send that to your friends.

To update the game later: upload the new `index.html` to the GitHub repo
(Add file → Upload files). Vercel redeploys on its own.

Or, if you have Node installed: open a terminal in this folder and run `npx vercel`.

## Playing together

1. Everyone opens the Vercel link.
2. One person goes to **Multiplayer → Host** and reads out the 5-character room code.
3. Everyone else goes to **Multiplayer → Join**, types the code, and joins.
4. Everyone picks a runner and enters the Block. The host starts runs from the shaft
   and rides the lifts; everyone else comes along.

Your runner, gear and money are saved in your own browser.

## If someone can't connect

Connections go straight between players' browsers. Most home internet works.
Some strict networks (work, school, some mobile hotspots) block that. Try a
different network if one player can't join.
